#pragma once

#include "operation.h"

//Add Rectangle operation class

class opLoad : public operation
{
public:
	opLoad(controller* pCont);
	virtual ~opLoad();

	//saves all shapes
	virtual void Execute();

};